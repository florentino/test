﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Test_SFTP
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked == true)
            {
                Test_SFTP.ConnectToSFTP.UploadFile(1, textBox1.Text, textBox2.Text, textBox3.Text, textBox4.Text, textBox5.Text, textBox6.Text);
            }
            if (radioButton2.Checked == true)
            {
                Test_SFTP.ConnectToSFTP.UploadFile(2, textBox1.Text, textBox2.Text, textBox3.Text, textBox4.Text, textBox5.Text, textBox6.Text);
            }
            

            /*
            foreach (string newPath in Directory.GetFiles(textBox1.Text, "*.*",
            SearchOption.AllDirectories))
                File.Copy(newPath, newPath.Replace(textBox1.Text, textBox2.Text), true);

            System.IO.DirectoryInfo di = new DirectoryInfo(textBox1.Text);

            foreach (FileInfo file in di.GetFiles())
            {
                file.Delete();
            }
            foreach (DirectoryInfo dir in di.GetDirectories())
            {
                dir.Delete(true);
            }
            */

            //bool isEmpty = Directory.EnumerateFiles(textBox1.Text).Any();

            //MessageBox.Show(isEmpty.ToString());

            /*
            if (Directory.EnumerateFiles(textBox1.Text).Any())
            {
                var directory = new DirectoryInfo(textBox1.Text);

                var myFile = (from f in directory.GetFiles("*.txt")
                              orderby f.LastWriteTime descending
                              select f).First();
                MessageBox.Show(myFile.ToString().Substring(0, 9).ToString());
            }
            */
            
        }
    }
}
