﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WinSCP;
using System.Diagnostics;
using System.Data;
using System.IO;

namespace Test_SFTP
{
    class ConnectToSFTP
    {
        //static string connString = "";
        //static string sourceFilePath = "";
        //static string ftpURL = "";
        static string ftpHostname = "";
        static string ftpUserName = "";
        static string ftpPassword = "";
        //static string ftpSSHFingerPrint = "";
        static string ftpICBSFilePath = "";
        static string sourceFolder = "";
        //static string SFTPlogPath = "";
        static string ftpPpkPath = "";


        public static bool UploadFile(int opt, string source, string destination, string hostname, string username, string password, string ppk)
        {
            bool success = false;
            try
            {

                //ftpURL = getFtpUrl();
                ftpHostname = hostname;
                ftpUserName = username;
                ftpPassword = password;
                ftpICBSFilePath = destination;
                sourceFolder = source;
                ftpPpkPath = ppk;

                //string ppkpath = ConfigData.get_glInterfaceConfigData(connString, ConfigData.get_ppkpath());  //ConfigurationManager.AppSettings["ppkpath"]; //add here
                //string ppkpath = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().GetName().CodeBase).ToString();
                string ppkpath = ftpPpkPath; //@"\\BDOWLAS14V\Certificates\SSH\id_bdowlas14v_rsa.ppk";
                SessionOptions sessionOptions = new SessionOptions
                {
                    Protocol = Protocol.Sftp,
                    HostName = ftpHostname,
                    UserName = ftpUserName,
                    Password = ftpPassword,
                    //SshHostKeyFingerprint = ftpSSHFingerPrint,
                    GiveUpSecurityAndAcceptAnySshHostKey = true, //added here 090717
                };

                sessionOptions.SshPrivateKeyPath = ppkpath; //added here
                //string filename = Path.GetFileName(sourceFilePath+ @"\ICBSBLF");
                //string ftpfullpath = @"/etc/ssh";//ftpURL + "/" + filename;
                using (Session session = new Session())
                {
                    //connect
                    //session.SessionLogPath = SFTPlogPath + @"\log.sftpLog";
                    //session.AddRawConfiguration("ResumeSupport", "2");
                    session.Open(sessionOptions);
                    //uploadfile
                    TransferOptions transferoptions = new TransferOptions();
                    //transferoptions.TransferMode = TransferMode.Binary; //Original and working
                    transferoptions.TransferMode = TransferMode.Automatic; //added here
                    transferoptions.FilePermissions = null;//added here
                    transferoptions.PreserveTimestamp = false;//added here
                    //Particularly with SFTP protocol, prevent additional .filepartsuffix from being added to uploaded fileslarger than 100KB
                    transferoptions.ResumeSupport.State = TransferResumeSupportState.Off;

                    TransferOperationResult transferResult;

                    if (opt == 1) //upload to sftp
                    {
                        transferResult = session.PutFiles(sourceFolder + @"\*", ftpICBSFilePath, true, transferoptions);
                        transferResult.Check();

                        if (transferResult.IsSuccess == true)
                        {
                            System.IO.DirectoryInfo di = new DirectoryInfo(sourceFolder);

                            foreach (FileInfo file in di.GetFiles())
                            {
                                file.Delete();
                            }
                            foreach (DirectoryInfo dir in di.GetDirectories())
                            {
                                dir.Delete(true);
                            }
                            success = true;
                        }
                    }
                    else //download from sftp
                    {
                        transferResult = session.GetFiles(ftpICBSFilePath + @"/*.txt", sourceFolder, false, transferoptions);
                        transferResult.Check();
                        if (transferResult.IsSuccess == true)
                        {
                            success = true;
                        }
                    }



                    /*
                    TransferOperationResult transferResult;
                    transferResult = session.PutFiles(sourceFolder + @"\*", ftpICBSFilePath, false, transferoptions);
                    transferResult = opt == 1 ? transferResult = session.PutFiles(sourceFolder + @"\*", ftpICBSFilePath, true, transferoptions) : session.GetFiles(ftpICBSFilePath + @"/*.txt", sourceFolder, false, transferoptions);
                    transferResult.Check();
                    if (transferResult.IsSuccess == true)
                    {
                        string listOfTransferredFiles = logHeader();
                        foreach (TransferEventArgs transfer in transferResult.Transfers)
                        {
                            listOfTransferredFiles += transfer.FileName + System.Environment.NewLine;   //added here 090717
                            success = true;
                        }
                        logger("Trasferred: " + listOfTransferredFiles);
                    }
                    */

                }

            }
            catch (SessionLocalException sle)
            {
                string errorDetail = "WinSCP: There was an error on communication with WINSCP process.  WINSCP cannot be found or executed";
                errorDetail += Environment.NewLine + "Message: " + sle.Message;
                errorDetail += Environment.NewLine + "Target Site: " + sle.TargetSite;
                errorDetail += Environment.NewLine + "Inner Exception: " + sle.InnerException;
                errorDetail += Environment.NewLine + "Stack Trace: " + sle.StackTrace;
                errorDetail += Environment.NewLine + "Stack Trace: " + sle.StackTrace;
                EventLog.WriteEntry("ORPrinting", "\nStack Trace:  " + sle.StackTrace + "\nMessage: SendFileToSFTP Module:  Error in WinSCP: There was an error on communication with WINSCP process.  WINSCP cannot be found or executed!" + sle.Message, EventLogEntryType.Error);
               


            }
            catch (SessionRemoteException sre)
            {
                string errorDetail = "WinSCP: There was an error on communication with WINSCP process.  WINSCP cannot be found or executed";
                errorDetail += Environment.NewLine + "Message: " + sre.Message;
                errorDetail += Environment.NewLine + "Target Site: " + sre.TargetSite;
                errorDetail += Environment.NewLine + "Inner Exception: " + sre.InnerException;
                errorDetail += Environment.NewLine + "Stack Trace: " + sre.StackTrace;
                errorDetail += Environment.NewLine + "Stack Trace: " + sre.StackTrace;
                EventLog.WriteEntry("ORPrinting", "\nStack Trace:  " + sre.StackTrace + "\nMessage: SendFileToSFTP Module:  Error in inSCP: There was an error on communication with WINSCP process.  WINSCP cannot be found or executed!" + sre.Message, EventLogEntryType.Error);
                

            }
            catch (Exception ee)
            {
                Console.WriteLine("Error in Uploading file processing");
                EventLog.WriteEntry("ORPrinting", "\nStack Trace:  " + ee.StackTrace + "\nMessage: SendFileToSFTP Module:  Error in Uploading file processing!" + ee.Message, EventLogEntryType.Error);
              

            }
            EventLog.WriteEntry("ORPrinting", "\nMessage: SendFileToSFTP Module: Success in WINSCP process.", EventLogEntryType.Information);

            return success;
        }

        public static void logger(String lines)
        {
            //string TransferredCompletedToICBSLog = SFTPlogPath.Trim();
            //System.IO.StreamWriter file = new System.IO.StreamWriter(TransferredCompletedToICBSLog + @"\TrasferredFilesLog.txt " + DateTime.Now.ToString(), true);
            //file.WriteLine(lines + System.Environment.NewLine);
            //file.Close();

            //CreateLogFiles.ErrorLog(TransferredCompletedToICBSLog + @"\FilesLog.txt ", lines.Trim());


        }

        public static string logHeader()
        {
            string header = string.Empty;
            header = "Files Log" + System.Environment.NewLine;
            header = header + "----------" + DateTime.Now.ToString() + "----------" + System.Environment.NewLine;
            return header;
        }

    }
}
